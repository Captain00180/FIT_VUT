Závislosti sú vypísané v súbore requirements.txt. Inštalovať sa dajú cez príkaz "pip install -r requirements.txt"
Aplikácia sa spúšťa skriptom pexesoland.py ("python3 pexesoland.py")