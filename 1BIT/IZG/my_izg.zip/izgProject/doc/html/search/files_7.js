var searchData=
[
  ['phongmethod_2ecpp',['phongMethod.cpp',['../phongMethod_8cpp.html',1,'']]],
  ['phongmethod_2ehpp',['phongMethod.hpp',['../phongMethod_8hpp.html',1,'']]]
];
