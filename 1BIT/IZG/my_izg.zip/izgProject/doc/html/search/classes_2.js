var searchData=
[
  ['czflagmethod',['CZFlagMethod',['../classCZFlagMethod.html',1,'']]]
];
