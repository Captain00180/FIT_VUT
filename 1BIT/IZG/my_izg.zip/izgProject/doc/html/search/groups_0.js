var searchData=
[
  ['01_2e_20implementace_20obslužných_20funkcí_20pro_20buffery',['01. Implementace obslužných funkcí pro buffery',['../group__buffer__tasks.html',1,'']]],
  ['07_2e_20implementace_20vykreslení_20králička_20s_20phongovým_20osvětlovacím_20modelem_2e',['07. Implementace vykreslení králička s phongovým osvětlovacím modelem.',['../group__cpu__side.html',1,'']]],
  ['05_2e_20implementace_20vykreslovacích_20funkcí',['05. Implementace vykreslovacích funkcí',['../group__draw__tasks.html',1,'']]],
  ['04_2e_20implementace_20obslužných_20funkcí_20pro_20framebuffer',['04. Implementace obslužných funkcí pro framebuffer',['../group__framebuffer__tasks.html',1,'']]],
  ['00_2e_20proměnné_2c_20inicializace_20_2f_20deinicializace_20grafické_20karty',['00. proměnné, inicializace / deinicializace grafické karty',['../group__gpu__init.html',1,'']]],
  ['03_2e_20implementace_20obslužných_20funkcí_20pro_20shader_20programy',['03. Implementace obslužných funkcí pro shader programy',['../group__program__tasks.html',1,'']]],
  ['06_2e_20implementace_20vertex_2ffragment_20shaderu_20phongovy_20metody',['06. Implementace vertex/fragment shaderu phongovy metody',['../group__shader__side.html',1,'']]],
  ['02_2e_20implementace_20obslužných_20funkcí_20pro_20vertex_20puller',['02. Implementace obslužných funkcí pro vertex puller',['../group__vertexpuller__tasks.html',1,'']]]
];
