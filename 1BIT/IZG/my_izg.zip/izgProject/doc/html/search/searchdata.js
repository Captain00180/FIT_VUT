var indexSectionsWithContent =
{
  0: "0abcdefgilmnoprstuvw~",
  1: "abcegimoptuw",
  2: "abcefgmptw",
  3: "abcdegimoprstuw~",
  4: "abegilmnprstuvw",
  5: "befiopv",
  6: "ai",
  7: "efuv",
  8: "0",
  9: "it"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

