var searchData=
[
  ['phongmethod',['PhongMethod',['../classPhongMethod.html',1,'']]]
];
