var searchData=
[
  ['takescreenshot',['takeScreenShot',['../classArguments.html#a830a8ebb96c1a04c951b6c35f014cc8d',1,'Arguments']]],
  ['time',['time',['../classCZFlagMethod.html#a7cd60dc6b4da7b084ad7385476c6334b',1,'CZFlagMethod']]]
];
