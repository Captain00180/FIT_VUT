var searchData=
[
  ['emptymethod',['EmptyMethod',['../classEmptyMethod.html',1,'']]]
];
