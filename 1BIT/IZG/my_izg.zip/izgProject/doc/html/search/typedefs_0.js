var searchData=
[
  ['bufferid',['BufferID',['../fwd_8hpp.html#a5114031b77b80ad895eff688720b7f93',1,'fwd.hpp']]]
];
