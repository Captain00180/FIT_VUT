// modul1.c
static int x;  // Proměnná x která je neviditelná pro ostatní moduly je nulovaná
extern int y;  // Proměnná y která by měla bejt někde jinde a nemusí když se nepoužívá
