// modul1.c
extern int x; // Komplátor ví že někde bude proměnná int x buď tady nebo někde jinde
int x = 55;   // Našel jí tady, pohoda
